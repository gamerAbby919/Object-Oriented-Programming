import java.util.Calendar;
import java.util.GregorianCalendar;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class ClockPane extends Pane {
    private int hour;
    private int minute;


public ClockPane() {
    setCurrentTime();
}

public ClockPane(int hour, int minute) {
    this.hour = hour;
    this.minute = minute;
}

public int getHour() {
    return hour;
}

public void setHour(int hour) {
    this.hour = hour;
    paintClock();
}

public int getMinute() {
    return minute;
}

public void setMinute(int minute) {
    this.minute = minute;
    paintClock();
}

public void setCurrentTime() {
    Calendar calendar = new GregorianCalendar();
    this.hour = calendar.get(Calendar.HOUR_OF_DAY);
    this.minute = calendar.get(Calendar.MINUTE);

    paintClock();
}

private void paintClock() {
    double clockRadius = Math.min(getWidth(), getHeight()) * 0.8 * 0.5;
    double centerX = getWidth() / 2;
    double centerY = getHeight() / 2;

    Circle circle = new Circle(centerX, centerY, clockRadius);
    circle.setFill(Color.CORAL);
    circle.setStroke(Color.LIGHTCORAL);
    Text t1 = new Text(centerX - 5, centerY - clockRadius + 12, "12");
    Text t2 = new Text(centerX - clockRadius + 3, centerY + 5, "9");
    Text t3 = new Text(centerX + clockRadius - 10, centerY + 3, "3");
    Text t4 = new Text(centerX - 3, centerY + clockRadius - 3, "6");

    double hLength = clockRadius * 0.8;
    double xHour = centerX + hLength * Math.sin(hour * (2 * Math.PI / 60));
    double yHour = centerY - hLength * Math.sin(hour * (2 * Math.PI / 60));
    Line hLine = new Line(centerX, centerY, xHour, yHour);
    hLine.setStroke(Color.GRAY);

    double minLength = clockRadius * 0.8;
    double xMinute = centerX + minLength * Math.sin(minute * (2 * Math.PI / 60));
    double yMinute = centerY - minLength * Math.sin(minute * (2 * Math.PI / 60));
    Line minLine = new Line(centerX, centerY, xMinute, yMinute);
    minLine.setStroke(Color.DARKGRAY);

    getChildren().clear();
    getChildren().addAll(circle, t1, t2, t3, t4, minLine, hLine);
}

@Override
public void setWidth(double width) {
    super.setWidth(width);
    paintClock();
}

@Override
public void setHeight(double height) {
    super.setHeight(height);
    paintClock();
}
}