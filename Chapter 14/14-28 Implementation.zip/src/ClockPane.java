import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class ClockPane extends Pane {
    private int hour;
    private int minute;
    private int second;


public ClockPane() {
    setCurrentTime();
}

public ClockPane(int hour, int minute, int second) {
    this.hour = hour;
    this.minute = minute;
    this.second = second;  
}

public int getHour() {
    return hour;
}

public void setHour(int hour) {
    this.hour = hour;
    paintClock();
}

public int getMinute() {
    return minute;
}

public void setMinute(int minute) {
    this.minute = minute;
    paintClock();
}

public int getSecond() {
    return second;
}

public void setSecond(int second) {
    this.second = second;
    paintClock();
}

public void setCurrentTime() {
    this.hour = (int) (Math.random() * 11);
    this.minute = (int) (Math.random() * 2);
    switch (this.minute) {
        case 0: this.minute = 0;
        break;
        case 1: this.minute = 30;
        break;
    }
    this.second = (int) (Math.random() * 59);
    System.out.println(hour + "\n" + minute + "\n" + second);
    paintClock();
}

private void paintClock() {
    double clockRadius = Math.min(getWidth(), getHeight()) * 0.8 * 0.5;
    double centerX = getWidth() / 2;
    double centerY = getHeight() / 2;
    boolean hVisible = true;
    boolean mVisible = true;
    boolean sVisible = true;



    Circle circle = new Circle(centerX, centerY, clockRadius);
    circle.setFill(Color.CORAL);
    circle.setStroke(Color.LIGHTCORAL);
    Text t1 = new Text(centerX - 5, centerY - clockRadius + 12, "12");
    Text t2 = new Text(centerX - clockRadius + 3, centerY + 5, "9");
    Text t3 = new Text(centerX + clockRadius - 10, centerY + 3, "3");
    Text t4 = new Text(centerX - 3, centerY + clockRadius - 3, "6");

    double hLength = clockRadius * 0.6;
    double xHour = centerX + hLength * Math.sin(((this.hour % 12) + (minute / 60)) * ((2 * Math.PI) / 12));
    double yHour = centerY - hLength * Math.cos(((this.hour % 12) + (minute / 60)) * ((2 * Math.PI) / 12));
    Line hLine = new Line(centerX, centerY, xHour, yHour);
    hLine.setStroke(Color.BLACK);

    double mLength = clockRadius * 0.7;
    double xMinute = centerX + mLength * Math.sin(this.minute * (2 * Math.PI / 60));
    double yMinute = centerY - mLength * Math.cos(this.minute * (2 * Math.PI / 60));
    Line mLine = new Line(centerX, centerY, xMinute, yMinute);
    mLine.setStroke(Color.DARKGRAY);

    double secLength = clockRadius * 0.8;
    double xSecond = centerX + secLength * Math.sin(this.second * (2 * Math.PI / 60));
    double ySecond = centerY - secLength * Math.cos(this.second * (2 * Math.PI / 60));
    Line sLine = new Line(centerX, centerY, xSecond, ySecond);
    sLine.setStroke(Color.RED);
    getChildren().clear();
    getChildren().addAll(circle, t1, t2, t3, t4);
    if (hVisible == true) {
        getChildren().addAll(hLine);
    }
    if (mVisible == true) {
        getChildren().addAll(mLine);
    }
    if (sVisible == true) {
        getChildren().addAll(sLine);
    }
} 

@Override
public void setWidth(double width) {
    super.setWidth(width);
    paintClock();
}

@Override
public void setHeight(double height) {
    super.setHeight(height);
    paintClock();
}
}