public class TestCoolShapes {
	public static void main(String[] args) {
		Triangle[] superCoolTriangles = new Triangle[4];
		superCoolTriangles[0] = Triangle triangle1 = new Triangle(1, 2, 3);
		superCoolTriangles[1] = Triangle triangle2 = new Triangle(2, 3, 4);
		superCoolTriangles[2] = Triangle triangle3 = new Triangle(3, 4, 5);
		superCoolTriangles[3] = Triangle triangle4 = new Triangle(4, 5, 6);
		superCoolTriangles[4] = Triangle triangle5 = new Triangle(5, 6, 7);
		System.out.println("The color is this triangle is: " + triangle1.toString());
		System.out.println("The area of this triangle is: " + triangle1.getArea());
		System.out.println("The perimeter of this triangle is: " + triangle1.getPerimeter());
	}
}
