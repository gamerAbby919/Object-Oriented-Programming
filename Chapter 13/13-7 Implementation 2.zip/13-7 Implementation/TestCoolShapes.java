public class TestCoolShapes {
	public static void main(String[] args) {
		Triangle[] superCoolTriangles = new Triangle[4];
		Triangle triangle1 = new Triangle(1, 2, 3);
		Triangle triangle2 = new Triangle(2, 3, 4);
		Triangle triangle3 = new Triangle(3, 4, 5);
		Triangle triangle4 = new Triangle(4, 5, 6);
		Triangle triangle5 = new Triangle(5, 6, 7);
		superCoolTriangles[0] = triangle1;
		superCoolTriangles[1] = triangle2;
		superCoolTriangles[2] = triangle3;
		superCoolTriangles[3] = triangle4;
		superCoolTriangles[4] = triangle5;
		System.out.println("The color is this triangle is: " + triangle1.toString());
		System.out.println("The area of this triangle is: " + triangle1.getArea());
		System.out.println("The perimeter of this triangle is: " + triangle1.getPerimeter());
	}
}
