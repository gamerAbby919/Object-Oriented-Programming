class Colorable {
	public interface howToColor {
		public abstract String colors();
	}
	
	class instructions implements howToColor {
		@Override
		public String colors() {
			return "Color All 3 Sides!";
		}
	}
}