public class GeometricObject {
		public String color = "Green";
		public boolean filled;
		public java.util.Date dateCreated;
		
		protected GeometricObject() {
			dateCreated = new java.util.Date();
		}
		
		protected GeometricObject(String color, boolean filled) {
			dateCreated = new java.util.Date();
			this.color = color;
			this.filled = filled;
		}
		
		public String getColor() {
			return color;
		}
		
		public boolean isFilled() {
			return filled;
		}
		
		public void setColor(String color) {
			this.color = color;
		}
		
		public void isFilled(Boolean filled) {
			this.filled = filled;
		}
		
		public java.util.Date getDateCreated() {
			return dateCreated;
		}
		
		@Override
		public String toString() {
			return "Made on: " + dateCreated + "\nColor: " + "\nFilled? " + filled;
		}
}
