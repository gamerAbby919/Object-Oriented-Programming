public class TestOctagons extends Octagon {
	public static void main(String[] args) {
		ComparableOctagon octagon1 = new ComparableOctagon(1,2);
		ComparableOctagon octagon2 = (ComparableOctagon)octagon1.clone();
		
		System.out.println(octagon1.compareTo(octagon2));
	}
}