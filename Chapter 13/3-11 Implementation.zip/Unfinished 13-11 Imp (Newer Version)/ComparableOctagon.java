public class ComparableOctagon extends Octagon implements Cloneable, Comparable<ComparableOctagon> {
	Octagon octagon1 = new Octagon(1,2);
	Octagon octagon2 = new Octagon(2,3);
	
	public ComparableOctagon(double side1, double side2) {
		super(side1, side2);
	}
	
	public int compareTo(ComparableOctagon octagon1) {
		if (octagon1.getArea() > getArea()) {
			return 1;
		}
		else if (octagon1.getArea() < getArea()) {
			return -1;
		}
		else {
			return 0;
		}
	}
	
	@Override
	public String toString() {
		return super.toString() + "Area: " + getArea();
	}
	
	@Override
	
	public Object clone() {
		try {
			return super.clone();
		}
		catch (CloneNotSupportedException ex) {
			return null;
		}
	}
}