public class TestCoolShapes {
	public static void main(String[] args) {
		Triangle triangle1 = new Triangle(1, 2, 3);
		System.out.println("The color is this triangle is: " + triangle1.toString());
		System.out.println("The area of this triangle is: " + triangle1.getArea());
		System.out.println("The perimeter of this triangle is: " + triangle1.getPerimeter());
	}
}
