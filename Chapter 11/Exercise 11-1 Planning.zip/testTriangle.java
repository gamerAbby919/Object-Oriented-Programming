class testTriangle {
	public static void main(String[] args) {
		Triangle triangle1 = new Triangle();
		triangle1.setSide1();
		triangle1.setSide2();
		triangle1.setSide3();
		triangle1.setArea();
		triangle1.setPerimeter();
		triangle1.toString();
	}
}