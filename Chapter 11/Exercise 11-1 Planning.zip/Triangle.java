
public class Triangle extends GeometricObject {
	double side1 = 0;
	double side2 = 0;
	double side3 = 0;
	
	public Triangle() {
	}
	
	//set side1
	public void setSide1() {
		this.side1 = side1;
	}
	
	//set side2
	public void setSide2() {
		this.side2 = side2;
	}
	
	//set side3
	public void setSide3() {
		this.side3 = side3;
	}
	
	//get area
	public double getArea() {
		return (side1 + side2 + side3)/ 2;
	}
	
	//set getArea
	public double setArea() {
		return (side1 + side2 + side3)/ 2;
	}
	
	//get perimeter
	public double getPerimeter() {
		return side1 + side2 + side3;
	}
	
	//set getPerimeter
	public double setPerimeter() {
		return side1 + side2 + side3;
	}
	
	//A description of the triangle
	public String toString() {
		return "Triangle: " + "\nArea:" + "\nSide 1:" + side1 + "\nSide 2:" + side2 + "\nside 3:" + side3 + "\n\n" + "Perimeter:" + getPerimeter();
	}
}