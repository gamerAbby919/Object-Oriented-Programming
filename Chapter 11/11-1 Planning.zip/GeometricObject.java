/*
Date: Sep 18th, 2024
Name: Abby Ralston
Assignment: Exercise 11-1, Planning
Description: Connect GeometricObject with Triangle, then get the area and perimeter for that triangle.
*/

public class GeometricObject {
		private String color = "white";
		private boolean filled;
		private java.util.Date dateCreated;
		
		//make a default geometric object
		public GeometricObject() {
			dateCreated = new java.util.Date();
		}
		
		/* Make geometric object withinin specified color and fill values*/
		public GeometricObject(String COlor, boolean filled) {
			dateCreated = new java.util.Date();
			this.color = color;
			this.filled = filled;
		}
		
		//return color
		public String getColor() {
			return color;
		}
		
		//set new color
		public void setColor(String color) {
			this.color = color;
		}
		
		//return fill (fill is a boolean statement, so isFilled works better) \(^o^)/
		public boolean isFilled() {
			return filled;
		}
		
		//set new fill
		public void setFilled(boolean filled){
			this.filled = filled;
		}
		
		//get date
		public java.util.Date getDateCreated() {
			return dateCreated;
		}
		
		//return a string representation of this object
		public String toString() {
			return "Created on" + dateCreated + "\ncolor: " + color + " and filled: " + filled;
		}
}