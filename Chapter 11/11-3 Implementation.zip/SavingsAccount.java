class SavingsAccount extends Account {
	double overdraftLimit = 0.00;
	boolean overdrafted;
	public String toString() {
		if (balance >= overdraftLimit) {
			overdrafted = false;
		}
		else if (balance < overdraftLimit) {
			overdrafted = true;
		}
		return "Balance: " + balance + "\n" + "Overdraft Limit: " + overdraftLimit;
	}
}