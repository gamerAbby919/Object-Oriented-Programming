class CheckingAccount extends Account {
	double overdraftLimit = -1000.00;
	boolean overdrafted;
	public String toString() {
		if (balance >= overdraftLimit) {
			overdrafted = false;
		}
		else if (balance < overdraftLimit) {
			overdrafted = true;
		}
		return "Balance: " + balance + " ";
	}
}