public class Account {
	int id = 0;
	double balance = 0;
	double annualInterestRate = 0;
	double withdraw = 0;
	double deposit = 0;
	//Account
	Account() {
		
	}
	
	//id and balance?
	Account(int id, double balance) {
		this.id = id;
		this.balance = balance;
	}
	
	void setID(int newID) {
		id = newID;
	}
	
	void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	
	//annual interest rate
	double annualInterestRate() {
		return annualInterestRate;
	}
	void setAIR(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	//withdraw
	double balwithdraw(double withdraw) {
		return this.balance = this.balance - withdraw;
	}
	
	double baldeposit(double deposit) {
		return this.balance = this.balance + deposit;
	}
	
	//date
	java.util.Date date = new java.util.Date();
	
}