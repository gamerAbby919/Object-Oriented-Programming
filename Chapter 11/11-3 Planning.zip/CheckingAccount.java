class CheckingAccount extends Account {
	double overdraftLimit = -1000.00;
	
}