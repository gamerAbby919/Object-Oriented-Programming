class testTriangleImp {
	public static void main(String[] args) {
		TriangleImp triangle1 = new TriangleImp();
		triangle1.setSide1();
		triangle1.setSide2();
		triangle1.setSide3();
		triangle1.setArea();
		triangle1.setPerimeter();
		triangle1.toString();
		triangle1.getColor();
		triangle1.isFilled();
		System.out.println(triangle1.toString() + "\n" + "Color: " + triangle1.getColor() + "\n" + "Filled: " + triangle1.isFilled());
	}
}