/*
Name: Abby Ralston
Date: Thu, Aug 22nd, 2024
Desc: Just improving upon MyIntegerPlanning
*/
public class MyIntegerImplementation {
	public static void main(String[] args) {
		MyInteger myInteger1 = new MyInteger(1);
		System.out.println("Here is your value: " + myInteger1);
		
		//myInteger1.isEven(1);
		System.out.println("Is your number even?" + "\n" + myInteger1.isEven(1));
		
		//myInteger1.isOdd(1);
		System.out.println("Is your number odd?" + "\n" + myInteger1.isOdd(1));
		
		//myInteger1.isPrime(1);
		System.out.println("Is your number a prime number?" + "\n" + myInteger1.isPrime(1));
		
		myInteger1.parsel("things");
		System.out.println("Here is the value of your word:" + "\n" + myInteger1.parsel("things"));
		
		myInteger1.equals(10);
		System.out.println("Is your number equal to value?" + "\n" + myInteger1.equals(10));
		
		char[] charArray = new char[5];
		charArray[0] = '1';
		charArray[1] = '7';
		charArray[2] = 'r';
		charArray[3] = 'B';
		charArray[4] = 's';
		
		myInteger1.parselInt(charArray);
		System.out.println("Here is the value of your character:" + "\n" + myInteger1.parselInt(charArray));
//		printValue(myInteger1);
	}
}

class MyInteger {
	int value = 0;
	
	MyInteger(int newValue) {
		value = newValue;
	}
	
	public boolean isEven() {
		return isEven(value);
	}
	
	public static boolean isEven(int evenOrNot) {
		if (evenOrNot % 2 == 0) {
				return true;
		}
		else {
			return false;
		}
	}
	
	public boolean isOdd() {
		return isOdd();
	}
	
	public static boolean isOdd(int oddOrNot) {
		if (oddOrNot % 2 == 0) {
				return false;
		}
		else {
			return true;
		}
	}
	
	public boolean isPrime() {
		return isPrime();
	}
	
	public static boolean isPrime(int primeOrNot) {
		if (primeOrNot == 1 || primeOrNot == 2) {
			return true;
		} else {
			for (int p = 2; p <= primeOrNot / 2; p++) {
				if (primeOrNot % p == 0) {
					return false;
				} 
			}
			return true;
			
		}
		
	}
	
	public boolean equals(int equalOrNot) {
		if (equalOrNot == value) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public static boolean isEqual() {
		return isEqual();
	}
	
	public static boolean isOdd(MyInteger a) {
		return isOdd(a.value);
	}
	
	public static boolean isEven(MyInteger b) {
		return isOdd(b.value);
	}
	
	public static boolean isPrime(MyInteger c) {
		return isOdd(c.value);
	}
	
	public boolean equals(MyInteger d) {
		if (d.value == value) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public static int parselInt(char[] charInt) {
		int returnInt = 0;
		for(int i = 0; i < charInt.length; i++) {
			returnInt += (int)charInt[i];
		}
		return returnInt;
	}
	
	public static int parsel(String strings) {
		int returnString = 0;
		for(int s = 0; s < strings.length(); s++) {
			returnString += (int)strings.charAt(s);
		}
		return returnString;
	}
	
}
