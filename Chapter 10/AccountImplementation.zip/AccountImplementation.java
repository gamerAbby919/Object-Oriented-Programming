import java.util.*;

/*
Name: Abby Ralston
Date: Mon. August 26th, 2024
Desc: Account Planning's Implementation
\(^o^)/
*/
public class AccountImplementation {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	
		Account[] accountArray = new Account[10];
		accountArray[0] = new Account(0, 100);
		accountArray[1] = new Account(1, 100);
		accountArray[2] = new Account(2, 100);
		accountArray[3] = new Account(3, 100);
		accountArray[4] = new Account(4, 100);
		accountArray[5] = new Account(5, 100);
		accountArray[6] = new Account(6, 100);
		accountArray[7] = new Account(7, 100);
		accountArray[8] = new Account(8, 100);
		accountArray[9] = new Account(9, 100);
//		account1.setID(1122);
//		account1.setBalance(20000);
//		account1.setAIR(1.045);
//		double aIR = account1.annualInterestRate;
//		double monthlyIR = aIR / 12;
//		account1.setBalance(10000);
//		double balance = account1.balance;
//		account1.balwithdraw(2500);		
//		account1.baldeposit(3000);
		int accountNum = 0;
//		
		while (true) {
			System.out.println("Welcome to the ATM machine! Enter your ID to get started!");
			int enterID = input.nextInt();
			for (int i = 0; i < accountArray.length; i++){
				if (enterID == accountArray[i].id) {
					accountNum = i;
					System.out.println("Welcome to your account: " + accountArray[accountNum].id + "!" + "\n" + "What would you like to do?" + "\n" + "1: View Current Balance" + "\n" + "2: Withdraw" + "\n" + "3: Deposit" + "\n" + "4: Exit");
					int accountDetails = input.nextInt();
						if (accountDetails == 1) {
							System.out.println("Your current balance is: $" + accountArray[accountNum].balance);
					}
						else if (accountDetails == 2) {
							System.out.println("How much money would you like to withdraw?");
							double withdrawMoney = input.nextDouble();
							accountArray[accountNum].balwithdraw(withdrawMoney);
							System.out.println("Your new balance is: $" + accountArray[accountNum].balance);
					}
						else if (accountDetails == 3) {
							System.out.println("How much money would you like to withdraw?");
							double depositMoney = input.nextDouble();
							accountArray[accountNum].baldeposit(depositMoney);
							System.out.println("Your new balance is: $" + accountArray[accountNum].balance);
					}
						else if (accountDetails == 4) {
							break;
					}
				}
			}
		}
			}
		}
		
//		

//	
//		System.out.println("Your ID num is: " + account1.id + "\n" + "Your current Balance is: " + account1.balance);
//		
//		//monthly interest (balance * (annual interest rate / 12)
//		//monthly interest rate (annual interest rate / 12)
//		System.out.println("Your annual interest rate is: " + account1.annualInterestRate + "\n" + "Your monthly interest rate is: " + monthlyIR);
//		
//		//withdraw (balance - withdraw)
//		//deposit (balance + deposit)
//		
//		System.out.println("Your new balance is: " + account1.balance);
//		
//		//date
//		java.util.Date dateCreated = new java.util.Date();
//		System.out.println("Your created your account " + dateCreated.getTime() + " milliseconds ago.");

class Account {
	int id = 0;
	double balance = 0;
	double annualInterestRate = 0;
	double withdraw = 0;
	double deposit = 0;
	//Account
	Account() {
		
	}
	
	//id and balance?
	Account(int id, double balance) {
		this.id = id;
		this.balance = balance;
	}
	
	void setID(int newID) {
		id = newID;
	}
	
	void setBalance(double newBalance) {
		this.balance = newBalance;
	}
	
	//annual interest rate
	double annualInterestRate() {
		return annualInterestRate;
	}
	void setAIR(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	//withdraw
	double balwithdraw(double withdraw) {
		return this.balance = this.balance - withdraw;
	}
	
	double baldeposit(double deposit) {
		return this.balance = this.balance + deposit;
	}
	
	//date
	java.util.Date date = new java.util.Date();
	
}