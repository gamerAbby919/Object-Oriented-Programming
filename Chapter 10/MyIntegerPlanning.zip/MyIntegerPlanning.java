public class MyIntegerPlanning {
	public static void main(String[] args) {
		MyInteger myInteger1 = new MyInteger(1);
		System.out.println("");
		
//		printValue(myInteger1);
	}
}

class MyInteger {
	int value = 0;
	
	MyInteger(int newValue) {
		value = newValue;
	}
	
	public boolean isEven() {
		return isEven(value);
	}
	
	public static boolean isEven(int evenOrNot) {
		if (evenOrNot % 2 == 0) {
				return true;
		}
		else {
			return false;
		}
	}
	
	public boolean isOdd() {
		return isOdd();
	}
	
	public static boolean isOdd(int oddOrNot) {
		if (oddOrNot % 2 == 0) {
				return false;
		}
		else {
			return true;
		}
	}
	
	public boolean isPrime() {
		return isPrime();
	}
	
	public static boolean isPrime(int primeOrNot) {
		if (primeOrNot == 1 || primeOrNot == 2) {
			return true;
		} else {
			for (int p = 2; p <= primeOrNot / 2; p++) {
				if (primeOrNot % p == 0) {
					return false;
				} 
			}
			return true;
			
		}
		
	}
	
	public boolean equals(int equalOrNot) {
		if (equalOrNot == value) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	public static boolean isEqual() {
		return isEqual();
	}
	
	public static boolean isOdd(MyInteger a) {
		return isOdd(a.value);
	}
	
	public static boolean isEven(MyInteger b) {
		return isOdd(b.value);
	}
	
	public static boolean isPrime(MyInteger c) {
		return isOdd(c.value);
	}
	
	public boolean equals(MyInteger d) {
		if (d.value == value) {
			return true;
		}
		
		else {
			return false;
		}
	}
	
	
}
	// object.isPrime(value);