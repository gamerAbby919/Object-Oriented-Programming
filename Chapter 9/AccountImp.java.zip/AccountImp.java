/*
Name: Abby Ralston
Date: Tue. August 20th, 2024
Desc: Account Planning's Implementation
\(^o^)/
*/
public class AccountImp {
	public static void main(String[] args) {
		Account account1 = new Account(1122, 20000);
		account1.setID(1122);
		account1.setBalance(20000);
		System.out.println("Your ID num is: " + account1.id + "\n" + "Your current Balance is: " + account1.balance);
		
		//monthly interest (balance * (annual interest rate / 12)
		//monthly interest rate (annual interest rate / 12)
		account1.setAIR(1.045);
		double aIR = account1.annualInterestRate;
		double monthlyIR = aIR / 12;
		System.out.println("Your annual interest rate is: " + account1.annualInterestRate + "\n" + "Your monthly interest rate is: " + monthlyIR);
		
		//withdraw (balance - withdraw)
		//deposit (balance + deposit)
		
		account1.setBalance(10000);
		double balance = account1.balance;
		account1.balwithdraw(2500);		
		account1.baldeposit(3000);
		System.out.println("Your new balance is: " + account1.balance);
		
		//date
		java.util.Date dateCreated = new java.util.Date();
		System.out.println("Your created your account " + dateCreated.getTime() + " milliseconds ago.");
	}
}

class Account {
	int id = 0;
	double balance = 0;
	double annualInterestRate = 0;
	double withdraw = 0;
	double deposit = 0;
	//Account
	Account() {
		
	}
	
	//id and balance?
	Account(int id, double balance) {
		id = id;
		balance = balance;
	}
	
	void setID(int newID) {
		id = newID;
	}
	
	void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	//annual interest rate
	double annualInterestRate() {
		return annualInterestRate;
	}
	void setAIR(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	//withdraw
	double balwithdraw(double withdraw) {
		return balance - withdraw;
	}
	
	double baldeposit(double deposit) {
		return balance + deposit;
	}
	
	//date
	java.util.Date date = new java.util.Date();
	
}